# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 00:26:15 2023

@author: Sambit Nath, Sibashish Padhy
"""

#install reqd libraries

# !pip install sklego
# !pip install statsforecast

import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.linear_model import LinearRegression
from sklego.meta import ZeroInflatedRegressor
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
from joblib import Parallel, delayed
from statsforecast.models import AutoARIMA, AutoETS, AutoCES, AutoTheta, HistoricAverage, RandomWalkWithDrift, SeasonalNaive, WindowAverage, SeasonalWindowAverage, ADIDA, CrostonClassic, CrostonOptimized, CrostonSBA, IMAPA, TSB, MSTL, Theta, OptimizedTheta, DynamicTheta, DynamicOptimizedTheta, GARCH, ARCH
#import statsmodels as sm
from statsmodels.tsa.api import SimpleExpSmoothing
from statsmodels.discrete.count_model import ZeroInflatedPoisson
import statsmodels.api as sm
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
import matplotlib.pyplot as plt
from dateutil.relativedelta import relativedelta, MO


#reading inputs

df = pd.read_csv(r'C:\Miscellaneous Projects\ATTMX_Intermittent_Model_Forecasting\inputs\Fact.DownloadResultf95dd9011ebc45c5b385584b29709735.csv')
time_dim = pd.read_csv(r'C:\o9 ATT\RCA\DP015SystemStat_20230525-103737\package\o9helpers\o9_data_folder\TimeDimension\000.csv')
forecast_start_date = '2022-10-31' #backtest cycle 1
forecast_end_date = pd.to_datetime(forecast_start_date) + relativedelta(months=12, weekday=MO(1))
dep_var = 'Actual'

#in ATT Mexico we are need forecast at planning month level

time_dim = time_dim[['Time.[Planning Month]','Time.[PlanningMonthKey]']].drop_duplicates()



time_dim['Time.[PlanningMonthKey]'] = pd.to_datetime(time_dim['Time.[PlanningMonthKey]'], format = '%Y-%m-%d')
time_dim['Time.[PlanningMonthKey]'] = pd.to_datetime(time_dim['Time.[PlanningMonthKey]']).map(lambda x: x.strftime('%Y-%m-%d'))
time_dim['Time.[PlanningMonthKey]'] = pd.to_datetime(time_dim['Time.[PlanningMonthKey]'], format='%Y-%m-%d')


#Creating tsid column
df['tsid'] = df['Item.[Stat Item]'].astype(str) + '_' + df['Sales Domain.[Stat Customer Group]'].astype(str) + '_' + df['Location.[Stat Location]'].astype(str)


#Time Series Formatting

df = pd.merge(df, time_dim, on = ['Time.[Planning Month]'], how='left')
df = df[['Time.[Planning Month]', 'Time.[PlanningMonthKey]', 'tsid', dep_var]]

time_dim2 = time_dim[(time_dim['Time.[PlanningMonthKey]']>=df['Time.[PlanningMonthKey]'].min()) & (time_dim['Time.[PlanningMonthKey]']<=forecast_end_date)]
time_dim2['key'] = 1
tsids = df[['tsid']].drop_duplicates()
tsids['key'] = 1
time_dim2 = pd.merge(time_dim2, tsids, on = 'key').drop('key', axis = 1)

df = pd.merge(df, time_dim2, on = ['Time.[Planning Month]', 'Time.[PlanningMonthKey]', 'tsid'], how='right')


#Creating train and test datasets

train = df[df['Time.[PlanningMonthKey]']<forecast_start_date]
test = df[df['Time.[PlanningMonthKey]']>=forecast_start_date]

train[dep_var] = train[dep_var].fillna(0)
min_dates= train[train[dep_var]>0].groupby(['tsid'])['Time.[PlanningMonthKey]'].min().reset_index(drop = False).rename(columns = {'Time.[PlanningMonthKey]':'min_dates'})
train = pd.merge(train, min_dates, on = 'tsid', how = 'right')
train = train[train['Time.[PlanningMonthKey]']>=train['min_dates']]
train.drop('min_dates', axis = 1, inplace = True)

test = test[test['tsid'].isin(train['tsid'].unique())]
test['Actual'] = np.nan


#Concatenating train and test to create ML features

df = pd.concat([train.reset_index(drop = True), test.reset_index(drop = True)])

print(df.shape)
lags_and_rolls = [7]

for i in lags_and_rolls:
  tempo = df[['Time.[PlanningMonthKey]', 'tsid', dep_var]].groupby(['Time.[PlanningMonthKey]', 'tsid'])[dep_var].sum().unstack().fillna(0)
  lagged_df = tempo.shift(i).fillna(0).stack().reset_index().rename(columns={0:'lag_'+str(i)})
  rolling_df = tempo.rolling(i).mean().shift(1).fillna(0).stack().reset_index().rename(columns={0:'rolling_'+str(i)})
  lagged_df = pd.merge(rolling_df, lagged_df, on = ['Time.[PlanningMonthKey]', 'tsid'], how = 'left')
  df = pd.merge(df, lagged_df, on = ['Time.[PlanningMonthKey]', 'tsid'], how = 'left')
print(df.shape)


# Creating temporal features to capture time series patterns from history (for ZIR)
df['monthnumber'] = df['Time.[PlanningMonthKey]'].dt.month
df['quarter'] = df['Time.[PlanningMonthKey]'].dt.quarter


################### Training and forecasting #######################################


train = df[df['Time.[PlanningMonthKey]']<forecast_start_date]
test = df[df['Time.[PlanningMonthKey]']>=forecast_start_date]


def training_and_forecasting(tsid):
    try:
        train_subset = train[train['tsid']==tsid]
        train_subset.set_index('Time.[PlanningMonthKey]', inplace = True)
        
        test_subset = test[test['tsid']==tsid]
        test_subset.set_index('Time.[PlanningMonthKey]', inplace = True)
        
        #### Instantiating models
        # intermittent statsforecast models and ZIR
        models = {
            #'autoarima' : AutoARIMA(season_length=12)
            #'autoets' : AutoETS(model = 'ZZZ', season_length=12),
            #'autoces' : AutoCES(model = 'Z', season_length=12),
            #'autotheta' : AutoTheta(season_length=12),
            #'histavg' : HistoricAverage(),
            #'RWD' : RandomWalkWithDrift(),
            #'SNaive' : SeasonalNaive(season_length=12),
            #'WindowAvg' : WindowAverage(window_size=12*3),
            #'SeasWindowAvg' : SeasonalWindowAverage(season_length=12, window_size=4),
            'adida' : ADIDA(),
            'crostonclassic' : CrostonClassic(),
            'crostonoptim' : CrostonOptimized(),
            'crostonsba' : CrostonSBA(),
            'imapa' : IMAPA(),
            'tsb' : TSB(alpha_d=0.5, alpha_p=0.5),
            #'mstl' : MSTL(season_length=[3, 52], trend_forecaster=AutoARIMA()),
            #'theta' : Theta(season_length=12),
            #'optimtheta' : OptimizedTheta(season_length=12),
            #'dynamicoptimtheta' : DynamicOptimizedTheta(season_length=12),
            #'garch' : GARCH(p=12, q=1),
            #'arch' : ARCH(p=12)
            'ZIR' : ZeroInflatedRegressor(
                classifier=SVC(),
                regressor=GradientBoostingRegressor(random_state=0)
            )
            #'ZIR_sm' : sm.ZeroInflatedPoisson(
            #    endog=train_subset[dep_var].values, exog=train_subset[['monthnumber' ,'quarter', 'rolling_7', 'lag_7']]
            #)
            }


        for key in models.keys():
            
            if key == 'ZIR':
                try:
                    models[key].fit(train_subset[['monthnumber' ,'quarter', 'rolling_7', 'lag_7']], train_subset[dep_var])
                    test_subset[str(key)+'_roc_auc'] = roc_auc_score(train_subset['Actual Cleansed']>0, models[key].classifier_.predict(train_subset[['monthnumber' ,'quarter', 'rolling_7', 'lag_7']])
, average=None)
                    test_subset[str(key)+'_fcst'] = models[key].predict(test_subset[['monthnumber' ,'quarter']])
                    
                except Exception as e1:
                    print(str(key) +' couldnt be trained for ' + tsid + ' because of ' + str(e1) + 'filling with SES')
                    test_subset[str(key)+'_fcst'] = SimpleExpSmoothing(train_subset[dep_var].values).fit().forecast(len(test_subset))
            
            #elif key == 'ZIR_sm':
            #    try:
            #        test_subset[str(key)+'_fcst'] = models[key].fit().predict(test_subset[['monthnumber' ,'quarter', 'rolling_12', 'lag_12']])
            #    except Exception as e2:
            #        print(str(key) +' couldnt be trained for ' + tsid + ' because of ' + str(e2) + 'filling with SES')
            #        test_subset[str(key)+'_fcst'] = SimpleExpSmoothing(train_subset[dep_var].values).fit().forecast(len(test_subset))
                    
            else:
                try:    
                    model = models[key].fit(y = np.asarray(train_subset[dep_var].values))
                    test_subset[str(key)+'_fcst'] = model.predict(h=len(test_subset))['mean']
                    #test_subset = test_subset.join(pd.DataFrame(model.predict(h=len(test_subset))['mean'], index = pd.date_range(start = forecast_start_date, periods = 78, freq='W-MON'))).rename(columns = {0:str(key)+'_fcst'})

                except Exception as e3:
                    print(str(key) +' couldnt be trained for ' + tsid + ' because of ' + str(e3)+ 'filling with SES')
                    test_subset[str(key)+'_fcst'] = SimpleExpSmoothing(train_subset[dep_var].values).fit().forecast(len(test_subset))

        
        return test_subset
        print('training and forecast completed for tsid ' + str(tsid))
        
    except Exception as e4:
        print(e4)
        
        
        
final_test = Parallel(n_jobs=8, prefer="threads")(delayed(training_and_forecasting)(i) for i in df['tsid'].unique())

output_df = pd.concat(final_test).reset_index()

print(output_df.head())

